
public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Persona per1=new Persona();
		Persona per2= new Persona();
		
		per1.setNombre("Javier");
		per1.setEdad(40);
		per1.setDni("484848");
		per1.setPeso(82.0f);
		per1.setAltura(1.80f);
		
		
		per1.setNombre("Elia");
		per1.setEdad(4);
		per1.setDni("4444");
		per1.setPeso(20.0f);
		per1.setAltura(1.10f);
		
		
		
		
		
	}

}
