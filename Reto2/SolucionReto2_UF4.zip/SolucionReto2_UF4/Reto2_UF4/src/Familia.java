
public abstract class Familia {

	protected int numeroLibroFamilia;
	protected String direccion;
	protected String poblacion;
	protected String provincia;
	
	
	
	public int getNumeroLibroFamilia() {
		return numeroLibroFamilia;
	}
	public void setNumeroLibroFamilia(int numeroLibroFamilia) {
		this.numeroLibroFamilia = numeroLibroFamilia;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getPoblacion() {
		return poblacion;
	}
	public void setPoblacion(String poblacion) {
		this.poblacion = poblacion;
	}
	public String getProvincia() {
		return provincia;
	}
	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}
	
	public abstract float imc();
	
	public abstract void imc2();
	
	
	
	
}
