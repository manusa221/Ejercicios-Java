
public class Empleado {
	
	protected String nombre;
	protected String apellidos;
	protected String dni;
	protected float salario;
	protected int edad;
	
	public Empleado()
	{
		this.nombre="Pepe";
		this.apellidos="Lopez";
		this.dni="449494";
		this.salario=2000.0f;
		this.edad=30;
	}
	public Empleado(String nombre, String apellidos, String dni, float salario, int edad)
	{
		this.nombre=nombre;
		this.apellidos=apellidos;
		this.dni=dni;
		this.salario=salario;
		this.edad=edad;
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public float getSalario() {
		return salario;
	}
	public void setSalario(float salario) {
		this.salario = salario;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public String print()
	{
		return this.nombre+ " - "+ this.apellidos+ " - "+ this.dni + " -"+ this.salario + " - "+ this.edad;
	}
	
	
	

}
