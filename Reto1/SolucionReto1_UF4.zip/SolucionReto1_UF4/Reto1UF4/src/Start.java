
public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Empleado emp= new Empleado();
		//Empleado emp2= new Empleado("Jose Juan","Gomez", "47474",1200.0f, 28);
		//System.out.println(emp2.getNombre());
		
		emp.setNombre("Javier");
		emp.setApellidos("Martin Martin");
		emp.setDni("4747447");
		emp.setSalario(2000.0f);
		emp.setEdad(40);
		
		System.out.println("Nombre: "+ emp.getNombre());
		System.out.println("Apellidos: "+ emp.getApellidos());
		System.out.println("Dni: "+ emp.getDni());
		System.out.println("Salario: "+ emp.getSalario());
		System.out.println("Edad: "+ emp.getEdad());
		
		
		
		System.out.println(emp.print());
		
		
		
	}

}
